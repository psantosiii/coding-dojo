from flask import Flask, render_template
app = Flask(__name__)
@app.route('/')
def welcome():
    return "Welcome!"
@app.route('/play')
def play():
    return render_template("index.html",num=3)
@app.route('/play/<x>/')
def play2(x):
    return render_template("index.html",num=int(x))
@app.route('/play/<x>/<color>/')
def play3(x,color):
    return render_template("index.html",num=int(x),color=str(color))
if __name__=="__main__":
    app.run(debug=True)
